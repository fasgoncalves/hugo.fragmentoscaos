---
title: "Revolução e Ruína: O 25 de Abril e os Dias do PREC"
slug: "revolucao-e-ruina-o-25-de-abril-e-os-dias-do-prec"
date: 2025-05-14
author: "Francisco Gonçalves e Augustus Veritas"
tags: ['história', 'política', 'Portugal', '25 de Abril', 'PREC']
description: "Uma análise crítica e profundamente documentada do 25 de Abril e dos dias conturbados que se seguiram. Este livro mergulha nas contradições, destruições e manipulações do PREC, com uma visão lúcida, livre e corajosa."
categories: ["Livros"]
cover:
  image: "/Covers/revolucao-e-ruina.jpg"
  alt: "Capa do livro Revolução e Ruína"
  relative: true
draft: false

---
# Revolução e Ruína – Resumo

Neste ensaio mordaz e profundamente lúcido, Francisco Gonçalves traça o percurso dramático de um país que ousou sonhar com liberdade, justiça e progresso — mas acordou décadas depois entre ruínas morais, políticas e sociais.

A obra **disseca os efeitos perversos da Revolução dos Cravos**, mostrando como o impulso transformador de Abril foi capturado por interesses partidários, corporativismos e mediocridades instaladas. A esperança popular foi sendo engolida pela máquina burocrática e pelos vícios de sempre: **corrupção, impunidade, nepotismo e alienação social**.

Com uma escrita crítica, mas também poética e visionária, o autor leva-nos por **fragmentos de memória, episódios simbólicos e análises cirúrgicas**, que revelam como o sonho revolucionário foi sendo diluído até restar apenas uma estrutura oca, vestida de democracia mas sustentada por conveniências e manipulações.

> “Não houve revolução – apenas uma substituição de donos.”

**"Revolução e Ruína" é uma acusação firme e um apelo à consciência.**  
Um livro que desmonta narrativas oficiais, desmascara os seus atores e devolve ao leitor a inquietação necessária para não aceitar o estado das coisas como inevitável.

---
---

# 📥 Download

🔹 [📘 PDF Version]( /downloads/revolucao-e-ruina.pdf )
🔹 [📗 EPUB Version]( /downloads/revolucao-e-ruina.epub )
🔹 [📱 Ler online](/html/revolucao-e-ruina.html)

*Partilha, lê, reflete. A ficção é também uma forma de verdade.*

---

# 📜 Excerto

*"Entre o fado e a revolução, entre o mar e a montanha, nasceu um país que poderia ter sido... ou ainda poderá ser."*

---
## ⚖️ Licença

Este livro está licenciado sob a
**[Creative Commons Atribuição–NãoComercial–PartilhaIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/)**.

Podes copiar, partilhar e adaptar a obra,
desde que atribuas ao autor, não uses para fins comerciais,
e partilhes com a mesma licença.

> *Porque partilhar conhecimento é libertar consciências.*
---

[⬅️ Voltar à Biblioteca](/)
