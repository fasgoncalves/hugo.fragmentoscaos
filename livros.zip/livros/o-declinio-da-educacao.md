---
title: "O Declínio da Educação"
slug: "o-declinio-da-educacao"
date: 2025-06-10
author: ["Francisco Gonçalves"]
description: "Um retrato profundo e satírico do colapso silencioso do sistema educativo português e das suas implicações sociais."
tags: ["educação", "crítica social", "democracia", "sátira"]
cover:
  image: "/Covers/ensaios-sobre-declinio-da-educacao.jpg"
  alt: "Capa do livro sobre o Declínio da Educação"
relative: true
draft: false
---

---

## O Declínio da Educação

Vivemos um tempo em que o saber já não é cultivado, mas certificado. O valor da educação foi substituído pela pressa dos diplomas prontos a levar. Conclua o 12.º ano em três meses, anunciam. E ninguém se indigna. Porque vivemos na era do simulacro — onde o que importa é parecer, não ser.

As escolas transformaram-se em centros de validação burocrática. Os professores foram reduzidos a meros funcionários de um sistema que não ensina a pensar, mas apenas a cumprir metas. E os alunos, em clientes impacientes que exigem notas, não conhecimento.

Este livro é uma denúncia. Mas também um alerta. Sobre o vazio que cresce nas salas de aula e no espírito crítico da sociedade. E sobre como esta degradação educacional não é um acidente — é um projeto. Um projeto funcional para um sistema que não quer cidadãos, mas apenas consumidores obedientes.

> “O verdadeiro perigo de uma educação fraca não é a ignorância. É a ilusão de saber.”

Leia. Reflita. E não aceite menos do que um ensino que ilumine.


Por: Francisco Gonçalves  
Publicado no blog Fragmentos do Caos em [ https://www.fragmentoscaos.eu ]

---

## 📥 Downloads

- 📄 [Download PDF](/downloads/ensaios-sobre-declinio-da-educacao.pdf)
- 📚 [Download EPUB](/downloads/ensaios-sobre-declinio-da-educacao.epub)
🔹 [🌐 HTML Version](/html/ensaios-sobre-declinio-da-educacao.html)


---

[⬅️ Voltar à Biblioteca](/)

---

## ⚖️ Licença

Este livro está licenciado sob a
**[Creative Commons Atribuição–NãoComercial–PartilhaIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/)**.

> *Porque a história não está nos manuais. Está no sangue das palavras —  
e na coragem de quem ainda acredita que um povo pode reescrever-se.*

             