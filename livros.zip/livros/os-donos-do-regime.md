---
title: "Os Donos do Regime"
slug: "os-donos-do-regime"
author: "Francisco Gonçalves"
date: 2025-05-14
tags: ["partidocracia", "cidadania", "democracia", "sátira", "política", "portugal"]
categories: ["Livros"]
cover:
  image: "/Covers/os-donos-do-regime.jpg"
  alt: "Capa do livro Os Donos do Regime"
  relative: true
draft: false


---

# Os Donos do Regime  
### Anatomia de uma Partidocracia em Decomposição

**Autor:** Francisco Gonçalves  
**Ano:** 2025  
**Género:** Ensaio político, sátira social, crítica cidadã

---

## Sinopse

Este livro é uma viagem feroz e lúcida pelo sistema político-partidário português, desvendando os seus bastidores, vícios e estratégias de perpetuação.  
Com um olhar crítico e uma escrita carregada de ironia, Francisco Gonçalves desmonta a ilusão da democracia representativa tal como ela é praticada em Portugal — mostrando como os partidos, longe de servirem o povo, se transformaram em máquinas de controlo, exclusão e degeneração institucional.

Cada capítulo revela um aspecto do regime: desde a fábrica de obediência que é a escola, até à simulação das eleições, passando pela fuga da inteligência e a captura total da representação.  
E termina com um capítulo propositivo, onde se delineia o que poderia ser uma nova democracia — participativa, direta, transparente.

---

## Estrutura

1. O Sistema Imunizado contra a Mudança  
2. A Escola da Obediência e o Currículo da Passividade  
3. Da Juventude Partidária à Cadeira Dourada  
4. As Máquinas de Captura e o Negócio da Representação  
5. A Arte de Excluir os Inteligentes  
6. As Eleições Como Simulação de Liberdade  
7. O Estado de Putrefacção Partidária  
8. E Depois do Regime? Visões para um País Libertado  
9. Epílogo – Quando a Cidadania Acordar

---

## Sobre o Autor

Francisco Gonçalves é um pensador livre, programador informático e autor de várias obras e ensaios sobre o estado da política, a sociedade e o futuro de Portugal.  
Nasceu para a insubmissão — e escreve para despertar consciências.  
Mantém o blogue [Fragmentos do Caos](http://www.fragmentoscaos.eu), onde publica com regularidade reflexões incisivas sobre o país.

---
## 📥 Download

🔹 [📘 PDF Version]( /downloads/os-donos-do-regime.pdf )
🔹 [📗 EPUB Version]( /downloads/os-donos-do-regime.epub )
🔹 [📱 Ler online](/html/os-donos-do-regime.html)

*Partilha, lê, reflete. A ficção é também uma forma de verdade.*

---

## 📜 Excerto

*"Entre o fado e a revolução, entre o mar e a montanha, nasceu um país que poderia ter sido... ou ainda poderá ser."*

---
## ⚖️ Licença

Este livro está licenciado sob a
**[Creative Commons Atribuição–NãoComercial–PartilhaIgual 4.0 Internacional](https://creativecommons.org/licenses/by-nc-sa/4.0/)**.

Podes copiar, partilhar e adaptar a obra,
desde que atribuas ao autor, não uses para fins comerciais,
e partilhes com a mesma licença.

> *Porque partilhar conhecimento é libertar consciências.*
---

[⬅️ Voltar à Biblioteca](/)
